# FRUS Annotation Sheet Builder v1 - StateChat-c / ChatGPT 5.4 Launch Handoff

Generated: 2026-06-30

## Primary Upload File

- `FRUS_Annotation_Sheet_Builder_v1_StateChat_C_ChatGPT_5_4_Agent_2026-06-30.md`

Upload this Markdown file to the standalone StateChat-c / ChatGPT 5.4 system as the agent instruction/context file for creating draft FRUS annotation sheets from PDF documents.

## Operator Script

- `FRUS_Annotation_Sheet_Builder_v1_StateChat_C_ChatGPT_5_4_Operator_Script_2026-06-30.txt`

Use this text file as the runbook for the closed-network operator. It includes model settings, upload order, drag-and-drop PDF prompts, batch mode, OCR triage, source-note-only mode, DOCX review-copy mode, post-run handling, and troubleshooting.

## Recent Published FRUS Reference

- `FRUS_Annotation_Sheet_Builder_v1_Recent_Published_FRUS_Lessons_2026-06-30.md`

This optional reference summarizes the recent history.state.gov corpus lessons embedded in the agent file: source-family preservation, common PDF archetypes, controlled annotation formulas, public-source handling, editorial-note limits, and date-basis separation.

## Recommended StateChat-c Setup

- Model: `gpt-5.4`
- Reasoning effort: `medium` for one clean PDF; `high` for batches, poor scans, attachments, source-note uncertainty, declassification questions, or DOCX output.
- Output: JSON-first. Use strict structured output if StateChat-c supports it.
- Temperature: low or deterministic, if configurable.
- Review posture: draft only from uploaded evidence; mark missing source provenance and archive path as evidence requests.

## Drag-And-Drop Workflow

1. Upload `FRUS_Annotation_Sheet_Builder_v1_StateChat_C_ChatGPT_5_4_Agent_2026-06-30.md`.
2. Add a short operator note with target volume/chapter if known.
3. Upload `FRUS_Annotation_Sheet_Builder_v1_Recent_Published_FRUS_Lessons_2026-06-30.md` if the operator wants the evidence summary visible in context; the key lessons are already embedded in the agent file.
4. Upload style guide, source list, manuscript spreadsheet, source register, or compiler instruction if available.
5. Drag and drop the PDF document or PDF batch into the context window.
6. Paste the standard run prompt from the operator script.
7. Save the JSON and copy-ready annotation-sheet draft together.

## Basic Operator Prompt

```text
Run FRUS Annotation Sheet Builder v1 on the uploaded PDF document inside StateChat-c with ChatGPT 5.4. Treat the PDF as a document a compiler wants to print in a FRUS volume. Inventory the file, identify extraction quality, extract visible metadata, distinguish document text from cover sheets and attachments, and produce a first-pass FRUS annotation sheet. Return JSON first using the v1 schema, then a copy-ready annotation-sheet draft. Do not invent source provenance, archive path, document number, cross-reference target, classification, declassification status, attachment treatment, participant list, drafting/clearance chain, or historical context not proved by uploaded evidence.
```

## Notes

- The builder is designed for drag-and-drop PDF intake on the standalone network.
- It produces drafts, not final publication-ready annotation sheets.
- Missing source provenance should stay visible as `[source provenance needed]`.
- Final manuscript numbers should come from compiler instruction or the FRUS Manuscript Document Numberer.
- The generated sheet should be run through FRUS Annotation Checker before final editorial use.
